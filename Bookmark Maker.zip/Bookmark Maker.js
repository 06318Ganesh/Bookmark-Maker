// Example Valid URLs: https://learning.ccbp.in/, https://www.google.com/
// Example Valid URLs: https://learning.ccbp.in/, https://www.google.com/

let bookMarkForm = document.getElementById("bookmarkForm");
let siteNameInput = document.getElementById("siteNameInput");
let siteUrlInput = document.getElementById("siteUrlInput");
let siteNameErrMsg = document.getElementById("siteNameErrMsg");
let siteUrlErrMsg = document.getElementById("siteUrlErrMsg");
let submitBtn = document.getElementById("submitBtn");
let bookMarksList = document.getElementById("bookmarksList");

function addBookmark() {
    let siteName = siteNameInput.value;
    let siteUrl = siteUrlInput.value;
    let listItem = document.createElement("li");
    bookMarksList.appendChild(listItem);
    let bookmarkName = document.createElement("p");
    let bookmarkUrl = document.createElement("a");
    bookmarkName.textContent = siteName;
    bookmarkUrl.textContent = siteUrl;
    bookmarkUrl.href = siteUrl;
    bookmarkUrl.setAttribute("target", "_blank");
    bookMarksList.classList.toggle("d-none");
    listItem.appendChild(bookmarkName);
    listItem.appendChild(bookmarkUrl);

}

siteUrlInput.addEventListener("change", function(event) {
    if (event.target.value === "") {
        siteUrlErrMsg.textContent = "Required";
    } else {
        siteUrlErrMsg.textContent = "";
    }
});

siteNameInput.addEventListener("change", function(event) {
    if (event.target.value === "") {
        siteNameErrMsg.textContent = "Required";
    } else {
        siteNameErrMsg.textContent = "";
    }
});

bookMarkForm.addEventListener("submit", function(event) {
    event.preventDefault();
    addBookmark();
});